Insert Into Users (firstname, lastName, Email, Password, superAdmin, createdDate, updatedDate)
Values ('Zach','Golder','zachgoldner@hotmail.com','Test0808',1,getdate(),getdate())